# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 22:06:08 2026

@author: VICTUS
"""
from subject import Subject
class Study_Tracker:
    def __init__(self):
        self.subjects={}
    def add_subject(self,name,target_hours):
        if name in self.subjects:
            print("Subject already exist")
        else :
            sub=Subject(name,target_hours)
            self.subjects[name]=sub
    def view_subjects(self):
        for sub in self.subjects.values():
            print("Subject:", sub.name)
            print("Target hours:", sub.target_hours)
            print("Real hours:", sub.real_hours)
            print("Status:", sub.status)
            print("----------------")
    def update_sub_hours(self,name,real_hours):
        if not isinstance( real_hours, (int ,float)):
            raise TypeError(" Real hours must be a number")
        if real_hours <0:
            raise ValueError("Real hours cannot be negative")
        
        if name not in self.subjects:
            raise ValueError("Subject not found in your plan")
        if real_hours>0:
            self.subjects[name].update_hours(real_hours)

    def total_real_hours(self):
        total=0
    
        for sub in self.subjects.values():
                total+=sub.real_hours
        return total
    def count_completed(self):
         count=0
         for sub in self.subjects.values():
             if sub.status=="completed":
                count+=1
        
         return count
    def count_uncompleted(self):
         count=0
         for sub in self.subjects.values():
             if sub.status=="not completed":
                 count+=1
         return count
    def clear_subjects(self):
        self.subjects.clear()
    def study_report(self):
    
        print("Study Report")
        print("----------------")
        print("total subjects:", len(self.subjects))
        print("total real hours:", self.total_real_hours())
        print("completed subjects:", self.count_completed())
        print("uncompleted subjects:", self.count_uncompleted())
            
    def load_subjects(self, data):
        for name, info in data.items():
            sub = Subject(info["name"], info["target_hours"])
            sub.real_hours=info["real_hours"]
            sub.status=info["status"]
            self.subjects[name]=sub
            
         
            
        
        
        
        
        
        
        
        
        
        
        
        
