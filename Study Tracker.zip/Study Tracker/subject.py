# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 22:17:56 2026

@author: VICTUS
"""

class Subject:
    def __init__(self,name,target_hours):
        #prevent the subject name from  being empty
        if name.strip()=="":
            raise ValueError("Subject name cannot be empty")
            
        #Target hours must be numbers 
        if not isinstance(target_hours, (int ,float)):
            raise ValueError ("Target hours must be a number")
            
        #Target hours must be positive
        if target_hours <0:
            raise ValueError("Target hours cannot be negative")
        
        self.name=name
        self.target_hours=target_hours
        self.real_hours=0
        self.status="not completed"
    def update_hours(self, real_hours):
          if not isinstance(real_hours, (int, float)):
                raise TypeError("Real hours must be a number")
    
          if real_hours < 0:
                raise ValueError("Real hours cannot be negative")
    
          self.real_hours = real_hours
          if self.real_hours >= self.target_hours:
                self.status = "completed"
          else:
            self.status = "not completed"