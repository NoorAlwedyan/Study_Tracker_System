# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 19:05:57 2026

@author: VICTUS
"""

import json

def save_data(subjects):
    data = {}

    for name, sub in subjects.items():
        data[name] = {
            "name": sub.name,
            "target_hours": sub.target_hours,
            "real_hours": sub.real_hours,
            "status": sub.status
        }

    with open("StudyData.json","w") as file:
        json.dump(data,file,indent=4)
        
def load_data():
    with open("StudyData.json","r") as file:
       data=json.load(file)
    
    return data

def clear_data():
    with open("StudyData.json", "w") as file:
        json.dump({}, file)