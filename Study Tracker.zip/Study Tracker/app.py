# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 22:07:00 2026

@author: VICTUS
"""

import streamlit as st
import json

from studytracker import Study_Tracker
from file_manager import save_data, load_data,clear_data


# Create tracker once
if "tracker" not in st.session_state:
    st.session_state.tracker = Study_Tracker()

tracker =st.session_state.tracker


# Load saved data once
if "data_loaded" not in st.session_state:
    try:
        data = load_data()
        tracker.load_subjects(data)

    except FileNotFoundError:
        pass

    except json.JSONDecodeError:
        st.error("Saved data is corrupted.")

    st.session_state.data_loaded = True


# Header
st.header("_Study Tracker_:blue[System] :sunglasses:")
st.write("Welcome to your study tracker!")


# Name
name = st.text_input("Enter your name:")

if name.strip() != "":
    st.write("Hello", name)


# Add subject
st.subheader("Add a subject")

with st.form("add_subject_form", clear_on_submit=True):
    subject_name = st.text_input("Subject name :")

    target_hours = st.number_input(
        "Target hours :",
        min_value=0.0,
        step=0.1,
    
    )

    submitted = st.form_submit_button("Add Subject")


if submitted:
    try:
        tracker.add_subject(subject_name, target_hours)
        save_data(tracker.subjects)

        st.success("Subject added successfully!")

    except ValueError as e:
        st.error(str(e))

    except TypeError as e:
        st.error(str(e))



# Update hours
st.subheader("Update study hours")

if len(tracker.subjects) > 0:

    with st.form("update_hours_form"):

        selected_subject = st.selectbox(
            "Choose a subject:",
            list(tracker.subjects.keys())
        )

        real_hours = st.number_input(
            "Enter real hours:",
            min_value=0.0,
            step=0.1
        )

        update_button = st.form_submit_button("Update Hours")

    if update_button:
        try:
            tracker.update_sub_hours(
                selected_subject,
                real_hours
            )

            save_data(tracker.subjects)

            st.success("Study hours updated successfully!")

        except ValueError as e:
            st.error(str(e))

        except TypeError as e:
            st.error(str(e))

else:
    st.info("Add a subject first.")
# Display subjects
st.subheader("My subjects")

if len(tracker.subjects) == 0:
    st.info("No subjects added yet.")

else:
    for name, sub in tracker.subjects.items():

        st.write(f"### {name}")

        st.write(
            f"Target: {sub.target_hours} hours | "
            f"Real: {sub.real_hours} hours | "
            f"Status: {sub.status}"
        )

        if sub.target_hours > 0:
            progress = sub.real_hours / sub.target_hours

            if progress > 1:
                progress = 1
            percentage = int(progress * 100)

            st.write(f"Progress: {percentage}%")
            st.progress(progress)
            

# Report
st.subheader("Study Report")
col1, col2, col3,col4 = st.columns(4)
with col1:
    st.metric("Total Subjects", len(tracker.subjects))
with col2:
    st.metric("Total Hours", tracker.total_real_hours())
with col3:
    st.metric("Completed",tracker.count_completed())
with col4:
    st.metric("Uncompleted", tracker.count_uncompleted())


# Clear all data
st.subheader("Clear Data")

if st.button("Clear All Data"):
    tracker.clear_subjects()
    clear_data()
    
    
    
    
    st.success("All data cleared successfully!")
    st.rerun()














