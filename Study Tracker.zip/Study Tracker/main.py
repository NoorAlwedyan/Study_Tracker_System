# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 22:07:03 2026

@author: VICTUS
"""
import json
from subject import *
from studytracker import Study_Tracker
from file_manager import save_data,load_data,clear_data
tracker=Study_Tracker()

#Add subjects:
tracker.add_subject("python", 3.45)
tracker.add_subject("math", 1)
tracker.add_subject("AI", 2)

#update real hours:
tracker.update_sub_hours("python", 4)
tracker.update_sub_hours("math", 2)

#view subjects:
tracker.view_subjects()

#study report :
tracker.study_report()
# Test error handling
try:
    tracker.update_sub_hours("Physics", 3)

except ValueError as error:
    print("Error:", error) 
    
    
try:
    tracker.update_sub_hours("python", -2)

except ValueError as error:
    print("Error:", error)   

# save all subjects in tracker
save_data(tracker.subjects) 
print("Data saved successfully")

new_tracker=Study_Tracker()
try:
    data=load_data()
    new_tracker.load_subjects(data)
    print("Data loaded successfully")
except FileNotFoundError:
    print("No saved data found")

except json.JSONDecodeError:
    print("Saved data is corrupted")

new_tracker.view_subjects()
   
print("Clearing all data...")

tracker.clear_subjects()
clear_data()

print("Data cleared successfully")
tracker.view_subjects()    
    
    
    
    
    
    
    
    
    
    